#include QMK_KEYBOARD_H

#define BASE 0

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
	[BASE] = LAYOUT(
		KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B,
		KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B,
		KC_B, KC_B, KC_B, KC_B, KC_B, KC_B, KC_B),

};

