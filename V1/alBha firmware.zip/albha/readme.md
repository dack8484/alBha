# AlBha

A 27-key, semi-ortho abomination copied from pyrol's alpha by dack!

Keyboard Maintainer: [dack8484](https://www.github.com/dack8484)

Hardware Supported: AlBha PCB, Pro Micro

Hardware Availability: gerbers and case files are open source.

Make example for Alpha (after setting up your build environment):

    make alBha:default

See [build environment setup](https://docs.qmk.fm/install-build-tools) then the [make instructions](https://docs.qmk.fm/faq/build-compile-qmk) for more information.

Please see [dack8484/alBha](https://www.github.com/dack8484/alBha) for gerbers and stuff.
